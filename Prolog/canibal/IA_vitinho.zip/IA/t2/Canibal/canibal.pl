

resultado :- jogo([3,3,esquerda],[0,0,direita],[[3,3,esquerda]],_). 

exibe([]) :- nl, nl. 
exibe([[Lista1,Lista2,Mensagem]|Cauda]) :- exibe(Cauda), write(Lista2), write(' - '), write(Lista1), write(' : '), write(Mensagem), nl. 

% Verifica se � possivel a travessia de acordo com as regras do jogo.
podeir([Missionario,Canibal,_]) :- (Canibal =< Missionario ; Missionario = 0) ,  C is 3-Canibal , M is 3-Missionario , (C =< M; M = 0).


jogo([Missionario,Canibal,Lado],[Missionario,Canibal,Lado],_,ListaMovidos):- nl , nl , exibe(ListaMovidos). 

%Nessa fun�ao faz a simula�ao da travessia de missionarios e de canibais
%Depois verifica essa travessia na fun�ao podeir,
%sendo possivel a travessia, caso essa mesma travessia nao pertence
%a lista de atravessados, chama fun�ao de jogo novamente 
%para novas travessia.
jogo([Missionario,Canibal,Lado],[M,C,L], Atravessados, Movimentos) :- 
   movimenta([Missionario,Canibal,Lado],[Mis,Can,Lad], Mensagem), 
   podeir([Mis,Can,Lad]),
   not(member([Mis,Can,Lad],Atravessados)), 
   jogo([Mis,Can,Lad],[M,C,L],[[Mis,Can,Lad]|Atravessados],[ [[Mis,Can,Lad],[Missionario,Canibal,Lado], Mensagem] | Movimentos ]). 

%simula a travessia de 1 missionario do lado esquerdo para o direito.
movimenta([Missionario,Canibal,esquerda],[M,Canibal,direita],'Um mission�rio atravessou o rio.') :- Missionario > 0, M is Missionario - 1. 
%simula a travessia de 2 missionario do lado esquerdo para o direito.
movimenta([Missionario,Canibal,esquerda],[M,Canibal,direita],'Dois mission�rios atravessaram o rio.') :- Missionario > 1, M is Missionario - 2.
% simula a travessia de 1 missionario e 1 canibal do lado esquerdo p/
% direito do rio.
movimenta([Missionario,Canibal,esquerda],[M,C,direita],'Um mission�rio e um canibal atravessaram o rio.') :- Missionario > 0, Canibal > 0, M is Missionario - 1, C is Canibal - 1.
% Simula a travessia de 1 canibal do lado esquerdo para o direito.
movimenta([Missionario,Canibal,esquerda],[Missionario,C,direita],'Um canibal atravessou o rio.') :- Canibal > 0, C is Canibal - 1.
%Simula a travessia de 2 canibal para o lado direito do Rio.
movimenta([Missionario,Canibal,esquerda],[Missionario,C,direita],'Dois canibais atravessaram o rio.') :- Canibal > 1, C is Canibal - 2.
%simula a volta de 1 missironario para o lado esquerdo do rio.
movimenta([Missionario,Canibal,direita],[M,Canibal,esquerda],'Um mission�rio voltou.') :- Missionario < 3, M is Missionario + 1.
%simula a volta de 2 missionario para o lado esquerdo do rio.
movimenta([Missionario,Canibal,direita],[M,Canibal,esquerda],'Dois mission�rios voltaram.') :- Missionario < 2, M is Missionario + 2.
%simula a volta de 1 missionario e 1 canibal para o lado esquerdo do rio
movimenta([Missionario,Canibal,direita],[M,C,esquerda],'Um mission�rio e um canibal voltaram.') :- Missionario < 3, Canibal < 3, M is Missionario + 1, C is Canibal + 1.
%Simula a volta de 1 canibal para o lado esquerdo do rio.
movimenta([Missionario,Canibal,direita],[Missionario,C,esquerda],'Um canibal voltou.') :- Canibal < 3, C is Canibal + 1.
%Simula a volta de 2 canibais para o lado esquerdo do Rio.
movimenta([Missionario,Canibal,direita],[Missionario,C,esquerda],'Dois canibais voltaram.') :- Canibal < 2, C is Canibal + 2. 



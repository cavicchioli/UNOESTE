pertence(X,[X|_]) :- !.
pertence(X,[_|Z]):- pertence(X,Z).


pode_ir(prudente,assis).
pode_ir(prudente,marilia).
pode_ir(marilia,bauru).
pode_ir(marilia,assis).
pode_ir(assis,ourinhos).
pode_ir(bauru,campinas).
pode_ir(bauru,ourinhos).
pode_ir(ourinhos,saopaulo).
pode_ir(campinas,saopaulo).

kilometragem(prudente,assis,127).
kilometragem(prudente,marilia,180).
kilometragem(marilia,bauru,109).
kilometragem(marilia,assis,74).
kilometragem(assis,ourinhos,70).
kilometragem(bauru,campinas,262).
kilometragem(bauru,ourinhos,130).
kilometragem(ourinhos,saopaulo,380).
kilometragem(campinas,saopaulo,101).


caminho(X,Y):-pode_ir(X,Y); pode_ir(Y,X).

km(X,Y,Km):-kilometragem(X,Y,Km);kilometragem(Y,X,Km).

rota(Origem, Destino, Cam):- rota(Origem, Destino, [Origem], Cam).
rota(Cidade, Cidade, Cam, Cam).
rota(Origem, Destino, Visitadas, Cam):- caminho(Origem, Visinha), not(pertence(Visinha, Visitadas)), rota(Visinha, Destino, [Visinha|Visitadas], Cam).


distancia(Origem, Destino, Cam, Km):-distancia(Origem, Destino, [Origem], Cam, Km).
distancia(Cidade, Cidade, Cam, Cam, 0).
distancia(Origem, Destino, Visitadas, Cam, X1):- caminho(Origem, Visinha), km(Origem,Visinha, Y1), not(pertence(Visinha, Visitadas)), distancia(Visinha, Destino, [Visinha|Visitadas], Cam, X2), X1 is X2 + Y1.


















oposto(d,e).
oposto(e,d).
permitido([FLR,C,FLR,FLR]):- oposto(FLR,C).
permitido([FC,FC,_,_]).
pode_ir([F,C,L,R],[NF,C,L,R]):- oposto(F,NF),permitido([NF,C,L,R]).
solucao(EST,NEST):- pode_ir(EST,NEST).

tamanho([],0).
tamanho([_|Cauda],T):-  tamanho(Cauda,Contaux), T is Contaux+1.

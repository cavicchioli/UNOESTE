pode_ir(prudente,marilia).
pode_ir(prudente,assis).
pode_ir(marilia,assis).
pode_ir(marilia,bauru).
pode_ir(assis,ourinhos).
pode_ir(bauru,ourinhos).
pode_ir(bauru,campinas).
pode_ir(ourinhos,spaulo).
pode_ir(campinas,spaulo).

km(prudente,marilia,180).


pertence(Elem,[Elem|_]).
pertence(Elem,[C|Cauda]):- Elem \= C, pertence(Elem,Cauda).

caminho(X,Y) :- pode_ir(X,Y);pode_ir(Y,X).
rota(Origem,Destino,Cam):- rota(Origem,Destino,[Origem],Cam).
rota(Cidade,Cidade,Cam,Cam).
rota(Origem,Destino,Visitadas,Cam):- caminho(Origem,Vizinha), not(pertence(Vizinha,Visitadas)),rota(Vizinha,Destino,[Vizinha|Visitadas],Cam).


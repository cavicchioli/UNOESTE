animal(canaraio).
animal(peixe).
animal(tubarao).
animal(vaca).
animal(morcego).
animal(avestruz).

anda(X) :- mamifero(X),X = vaca.
voa(X) :- canario(X),not(avestruz(X));morcego(X).
asas(X) :- passaro(X);X = morcego.
ovo(X) :- passaro(X);peixe(X),not(tubarao).
nada(X) :- peixe(X).
nnovo(X) :- nada(X),not(ovo(X)).

tubarao(tutu).
canario(tico).
peixe(nemo).
vaca(mimosa).
morcego(vamp).
avestruz(xica).
salmao(alfred).
amarelo(X):- canario(X).






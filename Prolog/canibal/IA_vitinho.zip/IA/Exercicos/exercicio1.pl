progenitor(maria,jose).
progenitor(joao,jose).
progenitor(joao,ana).
progenitor(jose,julia).
progenitor(jose,iris).
progenitor(iris,jorge).
progenitor(ana,antonio).

mulher(maria).
mulher(ana).
mulher(julia).
mulher(iris).

homem(joao).
homem(jose).
homem(jorge).
homem(antonio).

avo(X,Y) :- progenitor(X,Alguem), progenitor(Alguem,Y).
irmao(X,Y):- progenitor(Z,X),progenitor(Z,Y), X \=Y.
tio(X,Y):- irmao(X,Alguem),progenitor(Alguem,Y).
primo(X,Y):- tio(Alguem,Y),progenitor(Alguem,X).






%------------movimenta��o

pode_ir([C1,C2,C3,M1,M2,M3],[C1M1,C2,C3,NC1M1,M2,M3]):- oposto(C1M1,NC1M1), permitido([NC1M1,C2,C3,NC1M1,M2,M3]).
pode_ir([C1,C2C3,C2C3,M1,M2,M3],[C1,NC2C3,NC2C3,M1,M2,M3]):- oposto(C1C2,NC1C2),permitido([C1,NC2C3,NC2C3,M1,M2,M3]).
pode_ir([C1,C2,C3,M1M2,M1M2,M3],[C1,C2,C3,NM1M2,NM1M2,M3]):- oposto(M1M2,NM1M2), permitido([C1,C2,C3,NM1M2,NM1M2,M3]).
pode_ir([C1,C2,C3,M1,M2M3,M2M3],[C1,C2,C3,M1,NM2M3,NM2M3]):- oposto(M2M3,NM1M2), permitido([C1,C2,C3,NM1M2,NM1M2,M3]).
pode_ir([C1C2,C1C2,C3,M1,M2,M3],[NC1C2,NC1C2,C3,M1,M2,M3]):- oposto(C1C2,NC1C2), permitido([NC1C2,NC1C2,C3,M1,M2,M3]).
pode_ir([C1,C2C3,C2C3,M1,M2,M3],[C1,NC2C3,NC2C3,M1,M2,M3]):- oposto(C2C3,NC2C3), permitido([C1,NC2C3,NC2C3,M1,M2,M3]).


%-- lados

oposto(d,e).
oposto(d,e).


%como q tem q voltar

%pode monge e canibal
%pode 2monge e canibal
%pode 2 monge e 2canibal
%pode 3 monge e 1canibal
%pode 3monge e2 canibal

%ultimo estado
%pode 3monge e 3canibal


 

permitido([C1,])
permitido([C1M1,_,_,C1M1_,_]).


permitido([FLR,C,FLR,FLR]):- oposto(C,FLR).
permitido([FC,FC,_,_]).    


bonito(ursula).
bonito(norberto).
bonito(pierre).
rico(norberto).
rico(berta).
forte(berta).
forte(pierre).
forte(bruno).
amavel(bruno).

homem(norberto).
homem(pierre).
homem(bruno).
mulher(ursula).
mulher(berta).
      


%Todos os homens gostam de mulheres bonitas
gosta(X,Y) :- bonito(Y),mulher(Y),homem(X).

%Berta gosta de qualquer homem que gosta dela
gosta(X,Y) :- X = berta,homem(Y),gosta(Y,X).

%�rsula gosta de qualquer homem que gosta dela,contando que ele seja rico, am�vel, bonito e forte
gosta(X,Y) :- X = ursula,homem(Y),gosta(Y,X),rico(Y),amavel(Y),bonito(Y),forte(Y).

feliz(X) :- homem(X),rico(X).
%Qualquer homem que gosta de uma mulher que gosta dele � feliz
feliz(X):- homem(X),mulher(Y),gosta(X,Y),gosta(Y,X).  





oposto(d,e).
oposto(e,d).

pertence(X,[X|_]).
pertence(X,[_|Cauda]):- pertence(X,Cauda).


pode_ir([Pol,Pol1,Pol2,M,F1,F2,Poll,L,B],[NPol,Pol1,Pol2,M,F1,F2,Poll,L,NPol]):- 
	oposto(Pol,NPol),(Pol=B), not(nao_permite([NPol,Pol1,Pol2,M,F1,F2,Poll,L,NPol])).
pode_ir([Pol,Pol1,Pol2,M,F1,F2,Poll,L,B],[NPol,NPol,Pol2,M,F1,F2,Poll,L,NPol]):- 
	oposto(Pol,NPol),(Pol=Pol1, Pol=B), not(nao_permite([NPol,NPol,Pol2,M,F1,F2,Poll,L,NPol])).

pode_ir([Pol,Pol1,Pol2,M,F1,F2,Poll,L,B],[NPol,Pol1,NPol,M,F1,F2,Poll,L,NPol]):- 
	oposto(Pol,NPol),(Pol=Pol2, Pol=B), not(nao_permite([NPol,Pol1,NPol,M,F1,F2,Poll,L,NPol])).

pode_ir([Pol,Pol1,Pol2,M,F1,F2,Poll,L,B],[NPol,Pol1,Pol2,NPol,F1,F2,Poll,L,NPol]):-
	oposto(Pol,NPol),(Pol=M, Pol=B), not(nao_permite([NPol,Pol1,Pol2,NPol,F1,F2,Poll,L,NPol])).

pode_ir([Pol,Pol1,Pol2,M,F1,F2,Poll,L,B],[NPol,Pol1,Pol2,M,F1,F2,NPol,L,NPol]):- 
	oposto(Pol,NPol),(Pol=Poll, Pol=B), not(nao_permite([NPol,Pol1,Pol2,M,F1,F2,NPol,L,NPol])).

pode_ir([Pol,Pol1,Pol2,M,F1,F2,Poll,L,B],[Pol,Pol1,Pol2,NM,F1,F2,Poll,L,NM]):- 
	oposto(M,NM),(M=B), not(nao_permite([Pol,Pol1,Pol2,NM,F1,F2,Poll,L,NM])).

pode_ir([Pol,Pol1,Pol2,M,F1,F2,Poll,L,B],[Pol,Pol1,Pol2,NM,NM,F2,Poll,L,NM]):- 
	oposto(Pol,NM),(M=B, M=F1), not(nao_permite([Pol,Pol1,Pol2,NM,NM,F2,Poll,L,NM])).

pode_ir([Pol,Pol1,Pol2,M,F1,F2,Poll,L,B],[Pol,Pol1,Pol2,NM,F1,NM,Poll,L,NM]):- 
	oposto(M,NM),(M=B, M=F2), not(nao_permite([Pol,Pol1,Pol2,NM,F1,NM,Poll,L,NM])).

pode_ir([Pol,Pol1,Pol2,M,F1,F2,Poll,L,B],[Pol,Pol1,Pol2,NM,F1,F2,NM,L,NM]):- 
	oposto(M,NM),(M=B, M=Poll), not(nao_permite([Pol,Pol1,Pol2,NM,F1,F2,NM,L,NM])).

pode_ir([Pol,Pol1,Pol2,M,F1,F2,Poll,L,B],[Pol,Pol1,Pol2,M,F1,F2,NPoll,L,NPoll]):- 
	oposto(Poll,NPoll), (Poll=B), not(nao_permite([Pol,Pol1,Pol2,M,F1,F2,NPoll,L,NPoll])).

pode_ir([Pol,Pol1,Pol2,M,F1,F2,Poll,L,B],[Pol,NPoll,Pol2,M,F1,F2,NPoll,L,NPoll]):- 
	oposto(Poll,NPoll), (Poll=B, Poll=Pol1), not(nao_permite([Pol,NPoll,Pol2,M,F1,F2,NPoll,L,NPoll])).

pode_ir([Pol,Pol1,Pol2,M,F1,F2,Poll,L,B],[Pol,Pol1,NPoll,M,F1,F2,NPoll,L,NPoll]):- 
	oposto(Poll,NPoll), (Poll=B, Poll=Pol2), not(nao_permite([Pol,Pol1,NPoll,M,F1,F2,NPoll,L,NPoll])).

pode_ir([Pol,Pol1,Pol2,M,F1,F2,Poll,L,B],[Pol,Pol1,Pol2,M,NPoll,F2,NPoll,L,NPoll]):- 
	oposto(Poll,NPoll), (Poll=B, Poll=F1), not(nao_permite([Pol,Pol1,Pol2,M,NPoll,F2,NPoll,L,NPoll])).

pode_ir([Pol,Pol1,Pol2,M,F1,F2,Poll,L,B],[Pol,Pol1,Pol2,M,F1,NPoll,NPoll,L,NPoll]):- 
	oposto(Poll,NPoll), (Poll=B, Poll=F2), not(nao_permite([Pol,Pol1,Pol2,M,F1,NPoll,NPoll,L,NPoll])).

pode_ir([Pol,Pol1,Pol2,M,F1,F2,Poll,L,B],[Pol,Pol1,Pol2,M,F1,F2,NPoll,NPoll,NPoll]):- 
	oposto(Poll,NPoll), (Poll=B, Poll=L), not(nao_permite([Pol,Pol1,Pol2,M,F1,F2,NPoll,NPoll,NPoll])).


nao_permite([Pol, Pol1, Pol2, M, _, _, _, _, _]):-oposto(Pol,M), (M=Pol2; M=Pol1).
nao_permite([Pol, _, _, M, F1, F2, _, _, _]):- oposto(Pol,M), (Pol=F1; Pol=F2). 
nao_permite([Pol, Pol1, Pol2, F1, F2, M, Poll, L, _]):- oposto(Poll, L),(L=Pol; L=Pol1; L=Pol2; L=F1; L=F2; L=M).



imprime([]).
imprime([A|B]):-imprime(B), write(A),nl.


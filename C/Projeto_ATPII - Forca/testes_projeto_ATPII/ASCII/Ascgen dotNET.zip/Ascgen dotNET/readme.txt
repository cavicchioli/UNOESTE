Please note: You *need* to have the .NET framework 2.0 or higher installed to run this program.

Get it through Windows Update, or here:
http://msdn.microsoft.com/netframework/downloads/updates/default.aspx
(Choose the "Redistributable Package" for your system - probably x86)

Windows Vista comes with .NET 3.0 installed by default.


Any other problems, please post on my site:
http://ascgendotnet.jmsoftware.co.uk/
or http://sourceforge.net/projects/ascgen2/